const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const path = require('path');
const mongoose = require('mongoose');

app.use(bodyParser.json());

mongoose.connect('mongodb://localhost/restapi');

const TaskSchema = new mongoose.Schema({
    title: { type: String, required: true, minlength: 4 },
    description: { type: String, default: ""},
    completed: {type: Boolean, default: false},
}, {timestamps: true});

mongoose.model('Task', TaskSchema);
const Task = mongoose.model('Task')

// ROOT ROUTE/ DISPLAYS ALL
app.get('/tasks', function (req, res) {
    Task.find({},  function(err, tasks) {
        res.json(tasks);
    })
})
// CREATE A NEW TASK
app.post('/tasks', function (req, res) {
        var task = new Task( { title : req.body.title, description : req.body.description } )
        task.save(function(err,tasks) {
            if(err) {
                console.log('something went wrong');
            }
            else{
                console.log('successfully added')
                res.redirect('/tasks');
            }
        })
})

// RETRIEVE TASK BY ID
app.get('/tasks/:id', function (req, res) {
    Task.findOne({ _id : req.params.id}, function(err, tasks) {
        res.json(tasks);
    });var Tas
})

app.put('/tasks/:id', function(req, res) {
    Task.findById( req.params.id, function(err, tasks) {
        tasks.title = req.body.title;
        tasks.description = req.body.description;
        tasks.save(function(err, tasks) {
            if (err) {
                console.log('you haave an error');   
            }
            else {
                console.log('successfully updated')
                res.json(tasks);
            }
        })
    })
})

app.delete('/tasks/:id', function(req,res) {
    Task.findByIdAndRemove(req.params.id, function(err, tasks) {
    res.redirect('/tasks')
    })
})
app.listen(8000, function () {
    console.log("listening on post 8000");
})