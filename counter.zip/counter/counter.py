from flask import Flask, render_template,request,redirect, session

app = Flask(__name__)
app.secret_key = "Hidden"
app.count = 0

@app.before_first_request

def index():
	session['count'] = 0

@app.route('/')
def increment_by_one():
    session['count'] += 1
    #We only increment by 1 since reloading the page also increments
    return render_template('index.html')

app.run(debug=True)
